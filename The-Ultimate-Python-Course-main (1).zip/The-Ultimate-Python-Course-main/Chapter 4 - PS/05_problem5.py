a = (7, 0, 8, 0, 0, 9)

n = a.count(0)
print(n)