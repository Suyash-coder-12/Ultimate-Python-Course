a = 37

b = 5

print("Remainder when a is divided by b is", a % b)