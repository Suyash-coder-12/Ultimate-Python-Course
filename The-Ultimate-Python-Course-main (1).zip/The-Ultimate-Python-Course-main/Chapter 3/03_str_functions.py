name = "harry"

print(len(name))
print(name.endswith("rry"))
print(name.startswith("ha"))
print(name.capitalize())