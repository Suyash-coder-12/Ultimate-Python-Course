i = 1

while(i<51):
    print(i)
    i +=1 # or i = i + 1
'''
Output:
1
2
3
4
5
'''
