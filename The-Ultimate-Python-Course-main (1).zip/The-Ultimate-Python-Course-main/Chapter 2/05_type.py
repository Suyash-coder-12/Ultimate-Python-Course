a = "31.2"
b = float(a) # a but the type should be float
t = type(b) 

print(t)