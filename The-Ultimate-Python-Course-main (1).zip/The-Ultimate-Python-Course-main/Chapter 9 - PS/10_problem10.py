with open("this_copy.txt", "w") as f:
    f.write("")